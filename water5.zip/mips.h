#ifndef MIPS_H
#define MIPS_H
#include "water.h"

bool simulate_init();
int getfromstring(const string &zz);
inline bool valid(const char &xx);
void get_file();

#endif
